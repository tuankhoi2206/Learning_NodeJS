see labs/1-dockerized-node.md
