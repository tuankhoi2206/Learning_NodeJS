curl localhost:3000
curl localhost:3000/accounts
curl localhost:3000/accounts/10/transactions
