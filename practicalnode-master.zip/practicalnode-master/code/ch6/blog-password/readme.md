# Blog with admin password page

```
npm i
npm run seed
make test
npm start
```