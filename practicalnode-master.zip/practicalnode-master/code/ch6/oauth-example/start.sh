TWITTER_CONSUMER_KEY=ABCABC \
TWITTER_CONSUMER_SECRET=XYZXYZXYZ \
node -e "console.log(process.env.TWITTER_CONSUMER_KEY)"
node "twitter-oauth.js"