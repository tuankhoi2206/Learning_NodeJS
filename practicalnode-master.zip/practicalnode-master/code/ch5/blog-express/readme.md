# Blog with articles/posts

## Usage

```
npm i
npm run seed
make test
npm start
```

# Todo

* Markdown
* Edit post (modal, fetch data via AJAX)
* Photo upload
* salt password